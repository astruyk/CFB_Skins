Canadian Forces Base Skins V.1.0.1

Adds new skins for the base ARMA units inspired by Canadian Armed Forces.

Check out the project at: https://github.com/astruyk/CFB_Skins for more information.

Changelog

1.0.1
* Signed adding with unique key (not debug key)

1.0.0
* Added CADPAT Temperate Woodland skinned equipment:
  * Added CADPAT Combat Uniform
  * Added CADPAT Combat Uniform (Rolled Up)
  * Added CADPAT Combat Uniform (Tee)
  * Added CADPAT TW Assault Backpack
  * Added CADPAT TW Kitbag
  * Added CADPAT TW Tactical Vest
  * Added CADPAT TW Plate Carrier Lite
  * Added CADPAT TW Plate Carrier
* Added RCAF skinned equipment:
  * Added RCAF Flight Coveralls
* Added RCAF skinned vehicles:
  * Added CH-148 Cyclone
  * Added CH-146 Griffon
* Added 'Canadian Armed Forces' faction:
  * Added 'RCAF' class to CAF faction
  * Added 'CADPAT TW' class to CAF faction
* Added new units to CAF section based on NATO counterparts but using CADPAT skin variants:
  * Rifleman
  * Section Leader
  * Automatic Rifleman
  * Marksman
* Added new units to RCAF section based on NATO counterparts but using CADPAT skin variants:
  * Helicopter Pilot
  * Helicopter Crew