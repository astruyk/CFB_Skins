name = "CFB Skins 1.0.0";
picture = "logo.paa";
actionName = "Website";
action = "https://github.com/astruyk/CFB_Skins";
tooltip = "Canadian Forces Base Skins 1.0.0";
overview = "Canadian Armed Forces inspired skins for the base ARMA units and vehicles.";
author = "Anton Struyk";