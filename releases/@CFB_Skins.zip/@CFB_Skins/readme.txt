Canadian Forces Base Skins V.1.0.0

Adds new skins for the base ARMA units inspired by Canadian Armed Forces.

Check out the project at: https://github.com/astruyk/CFB_Skins